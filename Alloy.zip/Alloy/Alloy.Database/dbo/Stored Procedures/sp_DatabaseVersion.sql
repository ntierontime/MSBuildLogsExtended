﻿CREATE PROCEDURE [dbo].[sp_DatabaseVersion]
AS
	RETURN 7037
