﻿CREATE PROCEDURE dbo.sp_FxDatabaseVersion
AS
	RETURN 7000 --Note used since 7.5.500
