﻿CREATE TYPE [dbo].[LongParameterTable] AS TABLE (
    [Id] BIGINT NULL);

