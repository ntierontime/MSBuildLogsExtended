﻿CREATE TYPE [dbo].[ChangeNotificationStringTable] AS TABLE (
    [Value] NVARCHAR (450) COLLATE Latin1_General_BIN2 NULL);

