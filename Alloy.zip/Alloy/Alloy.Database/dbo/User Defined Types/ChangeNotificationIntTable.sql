﻿CREATE TYPE [dbo].[ChangeNotificationIntTable] AS TABLE (
    [Value] INT NULL);

