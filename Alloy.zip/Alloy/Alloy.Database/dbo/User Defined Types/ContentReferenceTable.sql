﻿CREATE TYPE [dbo].[ContentReferenceTable] AS TABLE (
    [ID]       INT            NULL,
    [WorkID]   INT            NULL,
    [Provider] NVARCHAR (255) NULL);

