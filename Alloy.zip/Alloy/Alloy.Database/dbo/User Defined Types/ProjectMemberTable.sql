﻿CREATE TYPE [dbo].[ProjectMemberTable] AS TABLE (
    [ID]   INT           NULL,
    [Name] VARCHAR (255) NULL,
    [Type] SMALLINT      NULL);

