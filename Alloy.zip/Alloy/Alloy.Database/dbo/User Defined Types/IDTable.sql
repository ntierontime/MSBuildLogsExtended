﻿CREATE TYPE [dbo].[IDTable] AS TABLE (
    [ID] INT NOT NULL);

