﻿CREATE TYPE [dbo].[StringParameterTable] AS TABLE (
    [String] NVARCHAR (255) NULL);

