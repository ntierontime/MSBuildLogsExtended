﻿CREATE TYPE [dbo].[UriPartsTable] AS TABLE (
    [Host] NVARCHAR (255)  NOT NULL,
    [Path] NVARCHAR (2048) NOT NULL);

