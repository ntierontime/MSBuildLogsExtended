﻿CREATE TYPE [dbo].[GuidParameterTable] AS TABLE (
    [Id] UNIQUEIDENTIFIER NULL);

