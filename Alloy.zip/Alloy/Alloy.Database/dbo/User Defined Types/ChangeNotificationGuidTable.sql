﻿CREATE TYPE [dbo].[ChangeNotificationGuidTable] AS TABLE (
    [Value] UNIQUEIDENTIFIER NULL);

