using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Alloy.Models.Pages
{
    /// <summary>
    /// Marker interface for search implementation
    /// </summary>
    public interface ISearchPage
    {
    }
}
